mTCP NetDrive Server
2025-01-10 Version
Michael Brutman (mbbrutman@gmail.com)

Home page: http://www.brutman.com/mTCP/mTCP.html


Welcome to mTCP!

  In this archive you will find the mTCP NetDrive server compiled for
  several different operating systems and architectures.  The documentation
  for the server can be found at the mTCP home page listed above.


Support

  I want you to have a great experience with mTCP and I provide support
  via email.  Please send your questions, bug reports and feature requests
  to me to me at the email address listed above.  There is also a low-volume
  mailing list you can subscribe to at https://groups.google.com/g/mtcp.

  The latest mTCP code and documentation can always be found at
  the home page listed above.  That is the official homepage for mTCP
  that I maintain.  Other sites may have mTCP available for download but
  I don't attempt to audit or verify those versions and they might be
  stale or have changes that I don't know about.  (Or they might have some
  really great code too ...)

  If you are running an older version of mTCP please try the latest
  version first before contacting me; your problem might be a bug
  that has already been fixed.


Like what you see?  Want to say thanks?

  Thank you!  I have never accepted any money, beer or cookies for my work.
  If you want to say thanks in a tangible way I've never seen an animal
  shelter that was over-funded.

  I also have mTCP stickers to hand out if you ever see me in person.


Licensing

  This version of the mTCP NetDrive Server is available as open
  source software under the terms of the GNU General Public License
  version 3.  Please see copying.txt which includes the terms of the
  license.

  In short, share and enjoy while respecting the license.  Although
  it is open source software I still maintain the copyright to all of
  my contributions.  As I retain my copyright I am able to offer other
  licenses; please contact me if you have a special project that requires
  a different license.

  The source code is available at (you guessed it!) the mTCP home page
  listed above.  It may be mirrored at other places but I don't have
  any control over those copies and I don't attempt to audit them or
  verify them.

  This code is free to use.  There is no warranty of any kind.  While I
  take pride in my work, this is a hobby project so if it burns down your
  house, causes an Martian invasion, or gives you indigestion I will
  feel badly but I am not legally responsible.


Comments or questions?  Email me at mbbrutman@gmail.com.


Lastly, enjoy!
-Mike
